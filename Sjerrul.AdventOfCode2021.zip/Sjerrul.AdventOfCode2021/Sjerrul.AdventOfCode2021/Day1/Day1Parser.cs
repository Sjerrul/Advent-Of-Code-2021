﻿using Sjerrul.AdventOfCode2021.Tools;

namespace Sjerrul.AdventOfCode2021.Day1
{
    public class Day1Parser : InputParserBase<string>
    {
        protected override string ParseLogic()
        {
            return this.rawFileContent;
        }
    }
}
