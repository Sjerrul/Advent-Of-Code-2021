﻿using Sjerrul.AdventOfCode2021.Core;

namespace Sjerrul.AdventOfCode2021.Day1
{
    public class Day1Solver : SolverBase<string, string>
    {
        protected override string SolveLogic(string input)
        {
            return input;
        }
    }
}
